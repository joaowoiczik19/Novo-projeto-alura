criaCartao(
    'Geografia',
    'O que Napoleão Bonaparte fez enquanto estava vivo?',
    'Napoleão Bonaparte foi um líder militar e político francês que se destacou na Revolução Francesa e ascendeu ao poder após um golpe de estado em 1799.'
)

criaCartao(
    'Geografia',
    'Qual a capital da França?',
    'A capital da França é Paris'
)

criaCartao(
    'Geografia',
    'Qual é o maios País do mundo?',
    'O maior País do mundo atualmente é a Rússia'
)

criaCartao(
    'Lingua inglesa',
    'Como se diz oi em Inglês?',
    'Oi em ingles é HI (RAI)'
)